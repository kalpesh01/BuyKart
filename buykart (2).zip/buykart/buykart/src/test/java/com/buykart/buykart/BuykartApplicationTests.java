package com.buykart.buykart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuykartApplicationTests {

	@Test
	void contextLoads() {
	}

}
