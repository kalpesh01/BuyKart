package com.buykart.buykart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.buykart.buykart.model.ProductCharges;

public interface ProductChargesRepository extends JpaRepository<ProductCharges, Long> {

}
